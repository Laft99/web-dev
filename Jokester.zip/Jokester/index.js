const jokes = require('give-me-a-joke');
const color = require('colors');
console.log("Random Dad joke".green);
jokes.getRandomDadJoke(function (joke) {
    console.log(joke.rainbow);
});

